<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Person;

class BirthCertificate extends Model
{
    protected $primaryKey = 'number';
    protected $table = 'birth_certificates';
    protected $fillable = ['number','date','place','cpf'];
    
    public function person(){
        return $this->belongsTo(Person::class,'cpf','cpf');
    }
}
