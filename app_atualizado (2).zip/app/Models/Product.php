<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
Use App\Models\Category;
Use App\Models\Company;

class Product extends Model
{
    protected $table = 'products';
    protected $fillable = ['name','price','description','category_id','company_id'];

    public function category() {
        return $this->belongsTo(Category::class, 'category_id', 'id');
    }

    public function company(){
        return $this->belongsTo(Company::class, 'company_id', 'id');
    }
}
