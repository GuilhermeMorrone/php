<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Product;

class Company extends Model
{
    protected $table = 'companies';
    protected $fillable = ['social_reason', 'fantasy_name', 'cnpj'];

    public function products(){
        return $this->hasMany(Product::class,'company_id','id');
    }
}
