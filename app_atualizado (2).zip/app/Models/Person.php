<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\BirthCertificate;

class Person extends Model
{
    protected $primaryKey = 'cpf';
    protected $table = 'persons';
    protected $fillable = ['cpf','name','rg','birth_date'];
    //

    public function birthCertificate(){
        return $this->hasOne(BirthCertificate::class,'cpf','cpf');
    }

    public function creditCards(){
        return $this->hasMany(creditCard::class,'person_cpf','cpf');
    }
}
